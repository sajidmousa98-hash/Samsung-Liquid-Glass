package de.robv.android.xposed;
public class XposedHelpers {
    public static Object findAndHookMethod(String clazz, ClassLoader loader, String method, Object... args) { return null; }
    public static Object callMethod(Object obj, String name, Object... args) { return null; }
    public static Object getObjectField(Object obj, String name) { return null; }
}
