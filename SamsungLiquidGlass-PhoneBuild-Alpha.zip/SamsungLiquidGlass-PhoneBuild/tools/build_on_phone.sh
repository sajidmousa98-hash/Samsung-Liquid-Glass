#!/data/data/com.termux/files/usr/bin/bash
# On-device APK build for SamsungLiquidGlass prototype.
# Runs as the normal Termux user; no root, no destructive operations.
set -Eeuo pipefail

say() { printf '\n[Samsung Liquid Glass] %s\n' "$*"; }
fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

[[ -n "${PREFIX:-}" && -d "$PREFIX" ]] || fail 'This script must run inside Termux (not via su/root).'
[[ "$(uname -m)" == 'aarch64' ]] || fail 'Phone-only build instructions currently support ARM64/aarch64.'
for c in java curl unzip python3; do command -v "$c" >/dev/null 2>&1 || fail "Missing $c. Install the packages listed in PHONE_BUILD.md."; done
[[ -n "${JAVA_HOME:-}" ]] || export JAVA_HOME="$PREFIX/lib/jvm/java-21-openjdk"
[[ -x "$JAVA_HOME/bin/java" ]] || fail 'OpenJDK 21 missing: pkg install openjdk-21'

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

SDK="${ANDROID_HOME:-$PREFIX/opt/android-sdk}"
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
[[ -f "$SDK/platforms/android-35/android.jar" ]] || {
  say 'Android SDK platform android-35 is missing.'
  fail 'Install android-35 with sdkmanager (see PHONE_BUILD.md), then retry.'
}

# Native ARM64 aapt2: Google Maven's x86_64 binary cannot run on Android.
AAPT2=""
for p in "$PREFIX/bin/aapt2" "$SDK/build-tools/36.1.0/aapt2" "$SDK/build-tools/36.0.0/aapt2"; do
  if [[ -x "$p" ]]; then AAPT2="$p"; break; fi
done
[[ -n "$AAPT2" ]] || fail 'Native aapt2 not found. Run: pkg install aapt2'

# Add an override to *this copy of the project only*; never change global Gradle settings.
python3 - "$AAPT2" <<'PY'
from pathlib import Path
import sys
p = Path('gradle.properties')
lines = [s for s in p.read_text().splitlines() if not s.startswith('android.aapt2FromMavenOverride=')]
lines += ['android.aapt2FromMavenOverride=' + sys.argv[1]]
p.write_text('\n'.join(lines) + '\n')
PY

printf 'sdk.dir=%s\n' "$SDK" > local.properties
mkdir -p "$HOME/.cache/samsung-liquid-glass" "$HOME/tmp"
GRADLE_VER='8.11.1'
GRADLE_DIR="$HOME/.cache/samsung-liquid-glass/gradle-$GRADLE_VER"
DIST="$HOME/.cache/samsung-liquid-glass/gradle-$GRADLE_VER-bin.zip"
if [[ ! -x "$GRADLE_DIR/bin/gradle" ]]; then
  say "Downloading official Gradle $GRADLE_VER (first time only)..."
  curl -fL --retry 3 --connect-timeout 20 \
    "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip" -o "$DIST" \
    || fail 'Gradle download failed. Check internet access and retry.'
  unzip -tqq "$DIST" || fail 'Downloaded Gradle ZIP is invalid.'
  unzip -oq "$DIST" -d "$HOME/.cache/samsung-liquid-glass" || fail 'Gradle extraction failed.'
fi

say 'Building debug APK, using Java + official Gradle + native aapt2...'
"$GRADLE_DIR/bin/gradle" \
  --no-daemon --max-workers=2 --console=plain \
  -Dorg.gradle.jvmargs='-Xmx1200m -XX:MaxMetaspaceSize=384m -Djava.io.tmpdir='$HOME'/tmp' \
  :app:assembleDebug

say 'Packing KernelSU module...'
python3 tools/package_ksu.py
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
ZIP="$ROOT/SamsungLiquidGlass-KernelSU-Alpha.zip"
[[ -s "$APK" && -s "$ZIP" ]] || fail 'Build did not produce both expected files.'
mkdir -p "$HOME/storage/downloads"
cp -f "$APK" "$HOME/storage/downloads/SamsungLiquidGlass-Alpha.apk"
cp -f "$ZIP" "$HOME/storage/downloads/SamsungLiquidGlass-KernelSU-Alpha.zip"
say 'Success: both files copied to your phone Downloads folder.'
printf 'APK: %s\nKernelSU ZIP: %s\n' \
  "$HOME/storage/downloads/SamsungLiquidGlass-Alpha.apk" \
  "$HOME/storage/downloads/SamsungLiquidGlass-KernelSU-Alpha.zip"
