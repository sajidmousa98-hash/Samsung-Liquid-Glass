#!/usr/bin/env python3
"""Build flashable KernelSU ZIP ONLY after an actual, compiled APK exists."""
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
APK = ROOT / 'app/build/outputs/apk/debug/app-debug.apk'
OUT = ROOT / 'SamsungLiquidGlass-KernelSU-Alpha.zip'
FILES = ROOT / 'ksu-module'

if not APK.is_file():
    raise SystemExit(
        'ERROR: LSPosed APK has not been built. First build the app/debug APK in '
        'Android Studio (Build > Build APK(s)), then rerun this packager. '
        'Do NOT flash the source ZIP as a KernelSU module.'
    )
with zipfile.ZipFile(APK, 'r') as input_apk:
    if 'classes.dex' not in input_apk.namelist():
        raise SystemExit('ERROR: APK has no classes.dex and cannot run hooks.')
    if 'assets/xposed_init' not in input_apk.namelist():
        raise SystemExit('ERROR: APK is missing LSPosed legacy entry point.')
with zipfile.ZipFile(OUT, 'w', compression=zipfile.ZIP_DEFLATED) as out:
    for path in sorted(FILES.iterdir()):
        if path.is_file():
            out.write(path, path.name)
    out.write(APK, 'payload.apk')
print(f'Created {OUT} ({OUT.stat().st_size:,} bytes).')
