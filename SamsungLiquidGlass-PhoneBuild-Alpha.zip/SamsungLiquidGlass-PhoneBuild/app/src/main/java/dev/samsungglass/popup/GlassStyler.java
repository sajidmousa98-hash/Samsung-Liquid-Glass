package dev.samsungglass.popup;

import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.TextView;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.XposedHelpers;

/** Styles the heads-up-only RemoteViews container; no system files are replaced. */
final class GlassStyler {
    private static final Set<View> PROCESSED =
            Collections.newSetFromMap(new WeakHashMap<View, Boolean>());

    static void style(View child) {
        if (child == null) return;
        if (!PROCESSED.add(child)) return;
        final float radius = dp(child, 22);
        child.setBackground(new GlassDrawable(child.getResources().getDisplayMetrics().density));
        child.setClipToOutline(true);
        child.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                if (view.getWidth() > 0 && view.getHeight() > 0) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            }
        });
        // White/translucent material in the references uses dark type.
        tintText(child, 0);
        if (child.isAttachedToWindow()) attemptBlur(child);
        else child.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View view) {
                attemptBlur(view);
                view.removeOnAttachStateChangeListener(this);
            }
            @Override public void onViewDetachedFromWindow(View view) { }
        });
    }

    private static void tintText(View child, int depth) {
        if (depth > 10) return;
        if (child instanceof TextView) {
            ((TextView) child).setTextColor(0xff242429);
        }
        if (child instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) child;
            int count = Math.min(g.getChildCount(), 80);
            for (int i = 0; i < count; i++) tintText(g.getChildAt(i), depth + 1);
        }
    }

    /**
     * Best-effort Samsung/AOSP behind-window blur through the hidden framework.
     * It may be unavailable or disabled by the ROM; the glass gradient remains.
     * This does NOT blur the notification text/icons.
     */
    private static void attemptBlur(View child) {
        try {
            Object root = XposedHelpers.callMethod(child, "getViewRootImpl");
            if (root == null) return;
            Object b = XposedHelpers.callMethod(root, "createBackgroundBlurDrawable");
            if (!(b instanceof Drawable)) return;
            XposedHelpers.callMethod(b, "setBlurRadius", (int) dp(child, 30));
            try { XposedHelpers.callMethod(b, "setCornerRadius", dp(child, 22)); }
            catch (Throwable ignored) { /* Vendor method signatures vary. */ }
            Drawable overlay = new GlassDrawable(child.getResources().getDisplayMetrics().density);
            child.setBackground(new LayerDrawable(new Drawable[]{(Drawable) b, overlay}));
        } catch (Throwable ignored) {
            // A translucent frosted-look gradient is the safe fallback.
        }
    }

    static float dp(View view, float dp) {
        return dp * view.getResources().getDisplayMetrics().density;
    }
}
