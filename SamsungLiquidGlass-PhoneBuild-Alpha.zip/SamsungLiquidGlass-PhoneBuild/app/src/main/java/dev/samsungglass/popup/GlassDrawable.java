package dev.samsungglass.popup;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Rounded frosted, translucent card with top light reflection and a subtle glass rim. */
final class GlassDrawable extends Drawable {
    private final float density;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int alpha = 255;
    private final RectF rect = new RectF();

    GlassDrawable(float density) {
        this.density = density;
        paint.setDither(true);
    }

    @Override public void draw(Canvas canvas) {
        Rect r = getBounds();
        if (r.width() <= 0 || r.height() <= 0) return;
        float rad = Math.min(22f * density, r.height() / 2f);
        rect.set(r.left + .6f * density, r.top + .6f * density,
                r.right - .6f * density, r.bottom - .6f * density);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(alpha);
        paint.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                new int[]{0xb4ffffff, 0x7cffffff, 0xa9ffffff},
                new float[]{0f, .53f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, rad, rad, paint);

        // Top gloss, fading toward the center of the card.
        paint.setShader(new LinearGradient(0, r.top, 0, r.top + r.height() * .62f,
                0x76ffffff, 0x00ffffff, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, rad, rad, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.25f * density);
        paint.setColor(0xcfffffff);
        paint.setAlpha(alpha);
        canvas.drawRoundRect(rect, rad, rad, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override public void setAlpha(int value) { alpha = value; invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
