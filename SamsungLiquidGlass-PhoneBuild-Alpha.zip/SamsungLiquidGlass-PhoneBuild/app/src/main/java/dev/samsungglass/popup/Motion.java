package dev.samsungglass.popup;

import android.os.SystemClock;
import android.view.View;
import android.view.animation.PathInterpolator;

import java.util.WeakHashMap;

/** Moves only the HUN child, not the shade or navigation UI. */
final class Motion {
    private static final WeakHashMap<View, Long> LAST_ENTER = new WeakHashMap<>();
    private static final PathInterpolator OUT = new PathInterpolator(.16f, .85f, .23f, 1f);

    static void enter(View child) {
        long now = SystemClock.uptimeMillis();
        Long last = LAST_ENTER.get(child);
        if (last != null && now - last < 650) return;
        LAST_ENTER.put(child, now);
        child.animate().cancel();
        child.setPivotX(child.getWidth() / 2f);
        child.setPivotY(0);
        child.setAlpha(.45f);
        child.setScaleX(.955f);
        child.setScaleY(.92f);
        child.setTranslationY(-GlassStyler.dp(child, 14));
        child.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(340).setInterpolator(OUT).start();
    }

    static void exit(View child) {
        child.animate().cancel();
        child.animate().alpha(0f).scaleX(.98f).scaleY(.96f)
                .translationY(-GlassStyler.dp(child, 9))
                .setDuration(180).setInterpolator(OUT).start();
    }
}
