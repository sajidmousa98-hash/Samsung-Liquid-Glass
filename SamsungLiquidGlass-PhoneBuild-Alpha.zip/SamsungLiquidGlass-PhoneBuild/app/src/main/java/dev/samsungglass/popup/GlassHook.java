package dev.samsungglass.popup;

import android.os.Build;
import android.view.View;

import java.util.Locale;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Samsung SystemUI-only LSPosed hooks. Uses exact method signatures found in the supplied APK. */
public final class GlassHook implements IXposedHookLoadPackage {
    private static final String PKG = "com.android.systemui";
    private static final String CONTENT =
            "com.android.systemui.statusbar.notification.row.NotificationContentView";
    private static final String ROW =
            "com.android.systemui.statusbar.notification.row.ExpandableNotificationRow";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName) || !isSamsung()) return;
        if (Build.VERSION.SDK_INT < 31) return;
        installContentHook(lp.classLoader);
        installAnimationHooks(lp.classLoader);
    }

    private static boolean isSamsung() {
        return "samsung".equalsIgnoreCase(Build.MANUFACTURER)
                || "samsung".equalsIgnoreCase(Build.BRAND);
    }

    private static void installContentHook(ClassLoader loader) {
        try {
            XposedHelpers.findAndHookMethod(CONTENT, loader, "setHeadsUpChild",
                    View.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                if (param.args[0] instanceof View) {
                                    GlassStyler.style((View) param.args[0]);
                                }
                            } catch (Throwable ignored) { /* Never destabilize SystemUI. */ }
                        }
                    });
            XposedBridge.log("SamsungLiquidGlass: hooked setHeadsUpChild(View)");
        } catch (Throwable t) {
            XposedBridge.log("SamsungLiquidGlass: content hook unavailable: " + t);
        }
    }

    private static void installAnimationHooks(ClassLoader loader) {
        try {
            XposedHelpers.findAndHookMethod(ROW, loader, "onAppearAnimationStarted",
                    boolean.class, boolean.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                if (isHeadsUp(param.thisObject)) {
                                    View hun = headsUpChild(param.thisObject);
                                    if (hun != null) Motion.enter(hun);
                                }
                            } catch (Throwable ignored) { }
                        }
                    });
            XposedBridge.log("SamsungLiquidGlass: hooked HUN appearance");
        } catch (Throwable t) {
            XposedBridge.log("SamsungLiquidGlass: appearance hook unavailable: " + t);
        }

        try {
            XposedHelpers.findAndHookMethod(ROW, loader, "setHeadsUpAnimatingAway",
                    boolean.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                if (Boolean.TRUE.equals(param.args[0])) {
                                    View hun = headsUpChild(param.thisObject);
                                    if (hun != null) Motion.exit(hun);
                                }
                            } catch (Throwable ignored) { }
                        }
                    });
            XposedBridge.log("SamsungLiquidGlass: hooked HUN dismissal");
        } catch (Throwable t) {
            XposedBridge.log("SamsungLiquidGlass: dismissal hook unavailable: " + t);
        }
    }

    private static boolean isHeadsUp(Object row) {
        try {
            return Boolean.TRUE.equals(XposedHelpers.callMethod(row, "isHeadsUpState"));
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static View headsUpChild(Object row) {
        try {
            Object layout = XposedHelpers.callMethod(row, "getShowingLayout");
            Object child = XposedHelpers.getObjectField(layout, "mHeadsUpChild");
            return child instanceof View ? (View) child : null;
        } catch (Throwable ignored) {
            return null;
        }
    }
}
