package dev.samsungglass.popup;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;

/** A tiny on-device instruction page. Actual styling runs only in SystemUI via LSPosed. */
public final class EntryActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        TextView text = new TextView(this);
        text.setTextSize(16);
        text.setTextColor(0xff242429);
        text.setPadding(28, 36, 28, 36);
        text.setGravity(Gravity.START);
        text.setText("SAMSUNG LIQUID GLASS — ALPHA\n\n" +
                "Detected: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android API: " + Build.VERSION.SDK_INT + "\n\n" +
                "1. Enable this app in LSPosed.\n" +
                "2. Set its scope to System UI (com.android.systemui).\n" +
                "3. Reboot the phone.\n" +
                "4. Enable normal heads-up notifications in Samsung settings.\n\n" +
                "Only heads-up popups are styled. Notification shade cards and apps that " +
                "do not generate heads-up notifications are not forced to appear.\n\n" +
                "Experimental: Samsung's background blur may be unavailable. " +
                "A frosted translucent gradient is used as fallback.\n\n" +
                "To recover: disable the LSPosed scope, then restart; or uninstall the app.");
        scroll.addView(text, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }
}
