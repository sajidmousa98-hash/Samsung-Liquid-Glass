# Build directly on the Samsung Galaxy S23 (Termux; no computer)

**Experimental alpha only.** This is a source archive, *not* a flashable module. A successful build does not confirm the animation will match the reference. There is a real risk of SystemUI crashes after enabling hooks; have a way to disable LSPosed without needing the Android UI.

## 1. Install Termux

Use F-Droid's official Termux listing: https://f-droid.org/packages/com.termux/

Launch Termux and run (without `su`):

```bash
pkg update && pkg upgrade -y
pkg install -y openjdk-21 android-sdk aapt2 python unzip curl
termux-setup-storage
```

When asked, allow storage access. An internet connection and roughly 2–4 GB of free storage may be needed.

## 2. Check Android platform 35

```bash
ls "$PREFIX/opt/android-sdk/platforms/android-35/android.jar"
```

If the file is not found, try installing it using SDK Manager:

```bash
SDK="$PREFIX/opt/android-sdk"
find "$SDK" -type f -name sdkmanager
```

Run the `sdkmanager` path printed by `find` with `--sdk_root="$SDK" 'platforms;android-35'`, via `bash` if required by Termux. Example if the manager is at `cmdline-tools/latest/bin/sdkmanager`:

```bash
bash "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" 'platforms;android-35'
```

Accept the SDK licenses if requested. The project has `compileSdk 35`.

## 3. Download and unpack this *PhoneBuild* ZIP

Save `SamsungLiquidGlass-PhoneBuild-Alpha.zip` to the phone **Downloads** folder. In Termux:

```bash
cd ~
unzip -o ~/storage/downloads/SamsungLiquidGlass-PhoneBuild-Alpha.zip
cd SamsungLiquidGlass-PhoneBuild
```

It is important to build in Termux's home directory and **not** under `/sdcard/Download`, because Gradle needs a writable and executable working directory.

## 4. Build + package automatically

```bash
bash tools/build_on_phone.sh
```

The helper uses the locally installed OpenJDK, platform 35, ARM64 `aapt2` and downloads **official Gradle 8.11.1** from services.gradle.org on the first run. It compiles `app-debug.apk`, checks its contents, creates the KernelSU ZIP, and copies both outputs to Downloads.

Outputs:
- `Downloads/SamsungLiquidGlass-Alpha.apk`
- `Downloads/SamsungLiquidGlass-KernelSU-Alpha.zip`

If Gradle fails, send the **last 40 lines of the terminal output**, making sure no private information is exposed. Builds have not been verified on this exact model/OS.

## 5. Install + enable (only after making a backup)

1. Install `SamsungLiquidGlass-Alpha.apk` from Downloads using Android's package installer (allow installation from that app if prompted).
2. Open LSPosed > Modules, enable `Samsung Liquid Glass`, and select ONLY **System UI (`com.android.systemui`)** in Scope.
3. You can use the LSPosed APK *without* the KernelSU companion ZIP; KernelSU is already providing root. Optional: install `SamsungLiquidGlass-KernelSU-Alpha.zip` in KernelSU > Modules (do not press Action if the APK was already installed).
4. Restart and test a normal heads-up notification. Test against the video; the alpha has not been verified to match it.

## Recovery

If the UI still works: disable the LSPosed module, reboot, remove the APK, and optionally uninstall the KernelSU companion module. If SystemUI repeatedly crashes, use the recovery/safe-mode procedure specific to your LSPosed and KernelSU versions to disable the LSPosed module before restarting. Do not replace `SystemUI.apk`.

**Security note:** Never upload private notifications or unredacted SystemUI logs. The build script runs as the normal Termux user and does not invoke `su`.
