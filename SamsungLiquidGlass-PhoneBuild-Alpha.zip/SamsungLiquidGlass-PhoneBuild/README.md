# Samsung Liquid Glass HUN — v0.1.0 Alpha (SOURCE PROJECT)

An **experimental**, Samsung-only LSPosed module for **heads-up notifications** using
KernelSU as a companion module installer. The goal is to approach the rounded,
translucent notification and motion shown in the two user-supplied iPhone recordings.

## What actually exists

- Java source for the LSPosed module (SystemUI hooks only).
- Translucent glass gradient, edge glint, rounded clipping, dark text and subtle
  entrance/exit animations.
- Best-effort hidden Android background-blur drawable (fallback if unavailable).
- Samsung checks in the APK hook and in the KernelSU module installer.
- A KernelSU ZIP packager that **refuses to produce a ZIP until a real APK is built**.
- A reversible approach: doesn't alter `/system` or replace `SystemUI.apk`.

## Status / limitations

**Not built or device-tested here.** This ZIP is a *source project*, not a flashable
KernelSU ZIP, and the final result is not verified as 1:1. Android SDK/Gradle and
physical Samsung device testing are required. There may be existing opaque SystemUI
row backgrounds that obscure the translucent glass. The background-blur call is
undocumented and may not work on One UI 9. The iOS animation is proprietary and
Samsung may render app content differently. Do not install on a critical daily driver
without a backup/recovery method.

This only restyles **heads-up notifications already permitted by Android**. It does
not force silent notifications to become popups, and does not cover every custom UI.

## Build on a computer

1. Install Android Studio with an Android SDK platform (API 35 or newer) and JDK 17.
2. Open this directory as a Gradle project in Android Studio, let it sync and install
   Android Gradle Plugin dependencies, then run **Build > Build APK(s)** for `app`.
3. Confirm that `app/build/outputs/apk/debug/app-debug.apk` exists.
4. Run: `python3 tools/package_ksu.py`.
5. Install **SamsungLiquidGlass-KernelSU-Alpha.zip** from KernelSU manager.
6. Reboot if asked, open the installed module in KernelSU, press **Action** to
   install the companion APK. Alternatively install the debug APK manually.
7. Open LSPosed > Modules > Samsung Liquid Glass; enable and scope to **System UI**
   (`com.android.systemui`). Reboot.
8. Select standard heads-up/pop-up notification style in Samsung's notification settings.

## To undo / recover

- In LSPosed, disable this module or its **System UI** scope, then reboot.
- In KernelSU, disable/remove `Samsung Liquid Glass HUN` and reboot.
- If the UI crashes, boot into a mode that disables modules and disable its LSPosed
  injection; exact recovery steps vary by root/LSPosed setup.
- Do not replace `SystemUI.apk`. It is used only as a reference for symbol checks.

## Verified symbols from the provided 93 MiB Samsung SystemUI.apk

All three below were present as defined methods in `classes3.dex`:

- `com.android.systemui.statusbar.notification.row.NotificationContentView.setHeadsUpChild(android.view.View)`
- `com.android.systemui.statusbar.notification.row.ExpandableNotificationRow.onAppearAnimationStarted(boolean, boolean)`
- `com.android.systemui.statusbar.notification.row.ExpandableNotificationRow.setHeadsUpAnimatingAway(boolean)`

Also present: `isHeadsUpState()` and `getShowingLayout()` in `ExpandableNotificationRow`,
with field `mHeadsUpChild` in `NotificationContentView`.

`SystemUI.apk` and recordings are **not redistributed** in this project.

## Development notes

The included `xposed-api-stubs.jar` is *compile-only*: placeholder method declarations
for the legacy LSPosed/Xposed API. Runtime hooks are supplied by LSPosed on the phone.
The module APK contains only our implementation, not any stub classes.

For troubleshooting, check LSPosed logs for `SamsungLiquidGlass:` startup lines.

For a step-by-step test and recovery checklist, see [`TESTING.md`](TESTING.md).
