# Device-testing checklist — Galaxy S23 / Android 17 / One UI 9

This alpha has NOT been device-tested. Build/install it only if you can use adb
and know how to disable an LSPosed module in recovery or safe mode.

## Before testing

1. Make a backup. Confirm adb connectivity and have an LSPosed safe-mode method.
2. Choose **Brief/Heads-up** notification style and permit popups for a test app.
3. Verify manufacturer is Samsung, KernelSU root is healthy, and LSPosed injection works.
4. Enable this module *only for System UI*, then reboot.

## Visual checks against both supplied reference recordings

- Notification anchored just below status bar/cutout; card width and margins.
- Rounded corners and border; icon, application name and timestamp placement.
- Translucency over bright and dark wallpaper; true behind-card blur when available.
- Entrance motion, timing and fade; not sliding or animating the entire shade.
- Updating a message in place (`Hi` -> `Hello`) without card flicker.
- Exit timing; no text, alpha or scale stuck after dismissing a popup.
- Multiple notifications in a row; no SystemUI crash or dropped touches.
- Test while screen is locked and while shade is expanded.

## Logs and troubleshooting

Check LSPosed logs for `SamsungLiquidGlass:` lines. If no lines appear,
verify LSPosed is active and scoped to `com.android.systemui`.
If status bar / notification shade behaves incorrectly, disable the LSPosed
module and reboot. If adb still connects, a possible recovery command is:

    adb shell su -c 'pm uninstall dev.samsungglass.popup'

Then reboot. Disabling the **KernelSU companion ZIP alone does not immediately
unhook an already loaded LSPosed APK**. The manager module and the hooked APK
are separate packages.

Do not upload full notification logs without reviewing them: they can contain
app names, message contents and other personal information.
