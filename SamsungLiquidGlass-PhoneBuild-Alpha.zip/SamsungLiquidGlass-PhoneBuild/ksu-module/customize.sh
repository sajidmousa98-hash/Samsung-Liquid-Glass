#!/system/bin/sh
# Sourced by KernelSU installer. Never touches /system.
[ "${KSU:-false}" = "true" ] || [ "${KSU:-0}" = "1" ] || abort "KernelSU is required."
manufacturer="$(getprop ro.product.manufacturer | tr '[:upper:]' '[:lower:]')"
brand="$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')"
if [ "$manufacturer" != "samsung" ] && [ "$brand" != "samsung" ]; then
    abort "Samsung Galaxy devices only; detected $manufacturer ($brand)."
fi
sdk="$(getprop ro.build.version.sdk)"
case "$sdk" in *[!0-9]*|'') abort "Could not determine Android API version." ;; esac
[ "$sdk" -ge 31 ] || abort "Android 12/API 31+ required."
[ -s "$MODPATH/payload.apk" ] || abort "APK payload missing. Use the packager in source project."
# No system files are mounted or modified.
touch "$MODPATH/skip_mount"
ui_print "- Samsung device verified (API $sdk)"
ui_print "- Requires LSPosed enabled with System UI scope"
ui_print "- After reboot, press KernelSU module Action to install companion APK"
