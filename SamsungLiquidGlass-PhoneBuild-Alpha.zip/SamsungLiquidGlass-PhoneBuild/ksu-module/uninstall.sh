#!/system/bin/sh
# On uninstall remove companion APK when the package manager is responsive.
# If removal fails, remove it manually in Settings > Apps after reboot.
pm uninstall dev.samsungglass.popup >/dev/null 2>&1 || true
