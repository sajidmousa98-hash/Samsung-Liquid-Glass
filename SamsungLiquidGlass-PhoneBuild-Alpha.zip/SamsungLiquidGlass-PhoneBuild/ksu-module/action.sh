#!/system/bin/sh
MODDIR=${0%/*}
apk="$MODDIR/payload.apk"
if [ ! -s "$apk" ]; then
  echo "ERROR: payload.apk not found"
  exit 1
fi
maker="$(getprop ro.product.manufacturer | tr '[:upper:]' '[:lower:]')"
brand="$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')"
if [ "$maker" != "samsung" ] && [ "$brand" != "samsung" ]; then
  echo "ERROR: This module supports Samsung devices only."
  exit 1
fi
size="$(wc -c < "$apk" | tr -d ' ')"
echo "Installing LSPosed companion APK with Android package manager..."
cat "$apk" | pm install -r -S "$size" -
status=$?
if [ "$status" -ne 0 ]; then
  echo "Installation failed. Install payload.apk manually and enable it in LSPosed."
  exit "$status"
fi
echo "Open LSPosed -> Modules -> Samsung Liquid Glass -> enable -> System UI scope -> reboot."
